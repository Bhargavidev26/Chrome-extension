(function () {
    const GEMINI_API_KEY = "AIzaSyCLETvQfM11hdZtcnseosxtgPrGegWQifE"; 

    function addDoubtButton() {
        console.log("Adding doubt button...");

        const problemTitle = document.querySelector('h1, div.ant-typography-h1, .problem-title, .css-1ydn1gj');
        console.log("Found problem title:", problemTitle);

        if (!problemTitle) {
            console.warn("⚠️ Problem title not found!");
            return;
        }

        if (document.getElementById('doubtButton')) {
            console.log("ℹ️ Doubt button already exists!");
            return;
        }

        // Create doubt button
        const doubtButton = document.createElement('button');
        doubtButton.id = 'doubtButton';
        doubtButton.style.marginLeft = '10px';
        doubtButton.style.cursor = 'pointer';
        doubtButton.style.border = 'none';
        doubtButton.style.background = 'transparent';
        doubtButton.style.padding = '5px';
        doubtButton.style.transition = '0.3s';

        // Add image icon
        const doubtIcon = document.createElement('img');
        const imageUrl = chrome.runtime.getURL('assets/play.png');  // ✅ Fixed image path
        console.log("Image URL:", imageUrl);
        doubtIcon.src = imageUrl;
        doubtIcon.alt = 'Doubt Icon';
        doubtIcon.style.width = '24px';
        doubtIcon.style.height = '24px';

        doubtButton.appendChild(doubtIcon);

        // Add event listener for button click
        doubtButton.addEventListener('click', () => {
            console.log("🟢 Doubt button clicked!");
            openAIModal();
        });

        if (problemTitle.parentNode) {
            problemTitle.parentNode.insertBefore(doubtButton, problemTitle.nextSibling);
        } else {
            console.warn("⚠️ Parent node not found. Appending to body instead.");
            document.body.appendChild(doubtButton);
        }

        console.log("✅ Doubt button added successfully!");
    }

    async function fetchGeminiResponse(problemDetails, userQuery) {
        try {
            console.log("🔄 Sending request to Gemini API...");

            const structuredPrompt = `
                Analyze the following problem and provide a structured response:

                **Problem Title:** ${problemDetails.title}
                **Problem Description:** ${problemDetails.description}
                **Input Format:** ${problemDetails.inputFormat}
                **Output Format:** ${problemDetails.outputFormat}
                **Constraints:** ${problemDetails.constraints}
                
                **User Query:** ${userQuery}

                ### Expected Response Format:
                1️⃣ **Understanding the Problem** - Explain in simple terms what the problem is asking.
                2️⃣ **Approach to Solve** - Provide a detailed approach before giving any code.
                3️⃣ **Code (if required)** - Provide a well-commented solution.
                4️⃣ **Code Explanation** - Explain each part of the code.

                **IMPORTANT:** DO NOT return only code. Ensure the response follows this structured format.
            `;

            const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    contents: [{ parts: [{ text: structuredPrompt }] }]
                })
            });

            const data = await response.json();
            console.log("🔍 API Response:", data);

            if (data.candidates && data.candidates.length > 0) {
                return data.candidates[0]?.content?.parts?.[0]?.text || "⚠️ No response from AI.";
            } else {
                console.error("❌ Unexpected API response format:", data);
                return "⚠️ AI response format issue.";
            }
        } catch (error) {
            console.error("❌ Error fetching response from Gemini API:", error);
            return "⚠️ Error communicating with AI.";
        }
    }

    function extractProblemDetails() {
        const inputOutputs = document.querySelectorAll('.coding_input_format__pv9fS.problem_paragraph');
        return {
            title: document.querySelector('h1, div.ant-typography-h1, .problem-title, .css-1ydn1gj')?.innerText || "Title not found",
            description: document.querySelector('.coding_desc__pltWY.problem_paragraph')?.innerText || "Description not found",
            inputFormat: inputOutputs[0]?.innerText || "Input format not found",
            outputFormat: inputOutputs[1]?.innerText || "Output format not found",
            constraints: document.querySelector('.coding_constraints__pv9fS.problem_paragraph')?.innerText || "Constraints not found"
        };
    }

    function observeTitleAndAddButton() {
        const observer = new MutationObserver((mutations, obs) => {
            const problemTitle = document.querySelector('h1, div.ant-typography-h1, .problem-title, .css-1ydn1gj');
            if (problemTitle) {
                console.log("✅ Title found! Adding doubt button...");
                addDoubtButton();
                obs.disconnect();
            }
        });

        observer.observe(document.body, { childList: true, subtree: true });
    }

    observeTitleAndAddButton();
})();
