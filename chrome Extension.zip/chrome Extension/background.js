// background.js
// Author:
// Author URI: https://
// Author Github URI: https://www.github.com/
// Project Repository URI: https://github.com/
// Description: Handles all the browser level activities (e.g. tab management, etc.)
// License: MIT

// fetch("https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateText?key=AIzaSyCLETvQfM11hdZtcnseosxtgPrGegWQifE", {
           

// background.js
// Author:
// Author URI: https://
// Author Github URI: https://www.github.com/
// Project Repository URI: https://github.com/
// Description: Handles all browser-level activities, including bookmark management and chatbot interactions.
// License: MIT

